

%: pragma GCC optimize(3,"Ofast","inline")
#include<bits/stdc++.h>
using std::cout; using std::endl;
#define int long long
#define try(i,a,b) for(register signed i=a;i<=b;++i)
#define throw(i,a,b) for(register signed i=a;i>=b;--i)
#define asm(i,x) for(register int i=head[x];i;i=edge[i].next)
namespace xin_io
{
	#define scanf nb = scanf
	#define debug cout<<"debug"<<endl
	#define gc() p1 == p2 and (p2 = (p1 = buf) + fread(buf,1,1<<2,stdin),p1 == p2) ? EOF : *p1++
	char buf[1<<20],*p1 = buf,*p2 = buf,output[100]; FILE *xinnb;int nb;typedef long long ll; typedef unsigned long long ull;
	void openfile() {xinnb = freopen("t.txt","r",stdin);} void outfile() {xinnb = freopen("o.txt","w",stdout);}
	inline int get()
	{
		register int s = 0,f = 1; register char ch = gc();	while(!isdigit(ch)) {if(ch == '-') f = -1; ch = gc();}
		while( isdigit(ch)) s = (s << 1) + (s << 3) + (ch xor 48),ch = gc();return s * f;
	}
	template<typename type>inline void write(type x,char out)
	{
		if(!x) return putchar('0'),putchar(out),void(); if(x < 0) putchar('-'),x = -x;
		register int cnt = 0;while(x) output[++cnt] = x % 10,x /= 10; 
		throw(i,cnt,1) putchar(output[i] xor 48);return putchar(out),void();
	}
}
using namespace xin_io; static const int maxn = 1e4+10,inf = 1e9+7; static const ll llinf = 2e17+7;
namespace xin
{
	class xin_edge{public:int next,ver,w;}edge[maxn];
	int head[maxn],cnt = 1;
	inline void add(int x,int y,int z) {edge[++cnt].ver = y; edge[cnt].w = z;edge[cnt].next = head[x];head[x] = cnt;}
	int n,m,k,s,t;
	int dep[maxn],q[maxn],hd,tl,cur[maxn];
	inline bool bfs()
	{
		memset(dep,0,sizeof(dep));
		q[tl = hd = 1] = s; cur[s] = head[s]; dep[s] = 1;
		while(tl <= hd)
		{
			register int x = q[tl++];
			asm(i,x)
			{
				register int y = edge[i].ver,z = edge[i].w;
				if(z and !dep[y])
				{
					dep[y] = dep[x] + 1;
					q[++hd] = y;
					cur[y] = head[y];
				}
			}
		}
		return dep[t];
	}
	int dfs(int x,int in)
	{
		if(x == t) return in;
		register int out = 0;
		for(register int i=cur[x];i;i=edge[i].next)
		{
			register int y = edge[i].ver,z = edge[i].w;
			if(z and dep[y] == dep[x] + 1)
			{
				register int res = dfs(y,std::min(in,z));
				edge[i].w -= res; edge[i xor 1].w += res;
				in -= res; out += res;
				if(!in) break;
			}
			cur[x] = i;
		}
		if(!out) dep[x] = 0;
		return out;
	}
	int a[maxn/30][maxn/30];
	int sum1,sum2,num1,num2,maxx = -llinf;
	#define bian(i,j) (i * 40 + j)
	const int dx[] = {0,0,-1,1},dy[] = {1,-1,0,0};
	inline bool check(int val)
	{
		memset(head,0,sizeof(head)); cnt = 1;
		s = maxn - 2; t = maxn - 1; int tot = 0;
		try(i,1,n) try(j,1,m)
			if((i + j) & 1) add(bian(i,j),t,val - a[i][j]),add(t,bian(i,j),0);
			else
			{
				add(s,bian(i,j),val - a[i][j]); add(bian(i,j),s,0);
				tot += val - a[i][j];
				try(k,0,3)
				{
					register int x = i + dx[k],y = j + dy[k];
					if(x >= 1 and x <= n and y >= 1 and y <= m) add(bian(i,j),bian(x,y),llinf),add(bian(x,y),bian(i,j),0);
				}
			}
		int temp = 0;
		while(bfs()) temp += dfs(s,llinf);
		return (temp == tot);
	}
	inline short main()
	{
		int T = get();
		while(T--)
		{
			n = get(); m = get();
			sum1 = sum2 = num1 = num2 = 0; maxx = 0;
			try(i,1,n) try(j,1,m)
			{
				a[i][j] = get();
				maxx = std::max(maxx,a[i][j]);
				if((i + j ) & 1)
				{
					sum2 += a[i][j];
					num2 ++;
				}
				else
				{
					sum1 += a[i][j];
					num1 ++;
				}
			}
			if(num1 xor num2)
			{	
				register int x = (sum1 - sum2) / (num1 - num2);
				if(x >= maxx and check(x))
					cout<<x * num2 - sum2<<endl;
				else cout<<-1<<endl;
			}
			else
			{
	//			cout<<"sum1 = "<<sum1<<" sum2 = "<<sum2<<endl;
				if(sum1 xor sum2) {cout<<-1<<endl;}
				else
				{
					register int l = maxx - 1,r = llinf >> 1;
					while(l != r - 1 and l < r)
					{
						register int mid = (l + r) >> 1;
						if(check(mid)) r = mid;
						else l = mid;
					}
					if(r >= (llinf >> 1ll)) {cout<<-1<<endl;}
					else cout<<r * num2 - sum2<<endl;
				}
			}
		}
		return 0;
	}
}
signed main(){return xin::main();}
