#!/bin/bash
printf "\nplease read the number of the testfile : ";
#printf "now start running\n";
read num; let i=1;
printf "\nplease read the name of the testfile : ";
read filename;
printf "\nnow start compiling the code : \n";
g++ -O2 judge.cpp -std=gnu++11 -DONLINE_JUDGE -o judge.out
printf "compile successfully and start running\n";
#printf "$num\n";
let cnt_a=0,cnt_w=0;
time while [ $i -le $num ]
do
	if ! timeout 4 time ./judge.out < ~/123/testcases/$filename$i.in >judge.ans;then
		printf "\nCase #$i : Time Limited Error\n";
		let i=i+1;let cnt_w=cnt_w+1; continue; 
		fi
	if diff -w -q judge.ans ~/123/testcases/$filename$i.out; then
		printf "\nCase #$i : Accepted\n";
		let cnt_a=cnt_a+1;
	else 
		printf "\nCase #$i : Wrong Answer\n";	
		let cnt_w=cnt_w+1;
	fi
	let i=i+1;
done
let float score=100-100/$num*$cnt_w;
printf "Score : $score pts\n";
