#!/bin/bash
let a=1;
printf "\nplease input the number of the testfiles : ";
read n;
printf "\nplease input the name of the testfiles : ";
read name;
printf "\nnow is compiling the std.cpp\n";
g++ -O2 std.cpp -o std.out -DONLINE_JUDGE -std=c++11;
printf "\nnow is compiling the rand.cpp\n"
g++ -O2 rand.cpp -o data.out -DONLINE_JUDGE -std=c++11;
while [ $a -le $n ]
do
	./data.out>~/123/testcases/$name$a.in;
	./std.out<~/123/testcases/$name$a.in >~/123/testcases/$name$a.out;
	printf "now is making the  $name$a.in and the $name$a.out  testfiles\n";
	let a=a+1;
done
printf "$n testfiles are all ready\n";
