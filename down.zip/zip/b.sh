#!/bin/bash
let a=0; let b=0;
printf "please wait for the compiling : \n";
g++ -O2 t1.cpp -o dif1.out -DONLINE_JUDGE; 	printf "the correct code is ready now \n"; sleep 0.05s;
g++ -O2 pai.cpp -o dif2.out -DONLINE_JUDGE; printf "the pai.cpp code is ready now \n"; sleep 0.05s;
#g++ -O2 rand.cpp -std=c++11 -o data.out >data.in -DONLINE_JUDGE; printf "the data.cpp is ready now \n"; sleep 0.05s;
printf "start running :\n";
while true
do
	let a=a+1; let b=b+1;
#	./data.out>data.in;
#	printf "time [1] = ";
	python3 rand.py > data.in;
	./dif1.out<data.in >dif1.ans;
#	python3 p.py < data.in > dif1.ans;
#	printf "\n";
#	printf "time [2] = ";
	./dif2.out<data.in >dif2.ans;
#	printf "\n";
	printf "Case #$a : ";
	if diff -b -q dif1.ans dif2.ans; then
		printf " Accepted\n";
#		cat dif1.ans;
#		cat dif2.ans;
	else
		printf " Wrong Answer\n";
#		cat dif1.ans;
#		cat dif2.ans;
		break;
	fi
done
